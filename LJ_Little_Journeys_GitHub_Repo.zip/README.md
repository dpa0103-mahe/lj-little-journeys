# LJ Little Journeys

A minimalistic, child-friendly flipbook platform for viewing and downloading books with watermark protection.

## 🚀 Deploy to Railway

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template/YOUR_TEMPLATE_ID)

## 📦 Features
- Flipbook view (1-page or 2-page mode)
- Download with watermark (paid users only)
- Admin dashboard for book uploads
- Stripe integration for payments
- Logo placeholder (replace with your own in `/public/logo.png`)

## ⚙️ Environment Variables (set these in Railway)
```
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_PUBLIC_KEY=your_stripe_public_key
DATABASE_URL=your_database_url
RAILWAY_STATIC_URL=auto
```
*Database will auto-deploy on Railway if `DATABASE_URL` is left empty.*

## 📂 How to Deploy
1. **Upload this repo to GitHub**
   - Create a new GitHub repo (e.g., `lj-little-journeys`)
   - Upload all files in this folder
2. **Deploy to Railway**
   - Click the 'Deploy on Railway' button above (replace `YOUR_TEMPLATE_ID` later)
   - Set environment variables
3. **Access Your Site**
   - Once deployed, Railway will give you a public URL

---
Made with ❤️ for children’s reading journeys.
