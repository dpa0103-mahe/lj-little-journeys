
export default function BookReader({ book }) {
  if (!book) return null
  return (
    <div className="p-4 bg-white rounded shadow">
      <h2 className="text-xl font-semibold">{book.title}</h2>
      <p className="text-sm text-gray-600">{book.author}</p>
      <div className="mt-4">{book.content}</div>
    </div>
  )
}
