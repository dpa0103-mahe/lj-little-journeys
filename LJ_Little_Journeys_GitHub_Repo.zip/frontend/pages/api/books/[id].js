
import fetch from 'node-fetch'
export default async function handler(req, res) {
  const backend = process.env.BACKEND_URL || 'http://localhost:4000'
  const { id } = req.query
  if (req.method === 'GET') {
    const r = await fetch(`${backend}/books/${id}`)
    const data = await r.json()
    return res.status(r.status).json(data)
  } else if (req.method === 'PUT') {
    const r = await fetch(`${backend}/books/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json', 'Authorization': req.headers.authorization || '' }, body: JSON.stringify(req.body) })
    const data = await r.json()
    return res.status(r.status).json(data)
  }
  res.status(405).end()
}
