
import fetch from 'node-fetch'
export default async function handler(req, res) {
  const backend = process.env.BACKEND_URL || 'http://localhost:4000'
  const r = await fetch(`${backend}/auth/login`, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(req.body) })
  const data = await r.json()
  res.status(r.status).json(data)
}
