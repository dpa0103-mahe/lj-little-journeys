
export default function AdminIndex() {
  return (
    <main className="min-h-screen p-8 bg-gray-50">
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      <p className="mb-4">Use the sidebar to manage users, books, and billing. This is a minimal placeholder UI — extend as needed.</p>
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded shadow">Users Management (placeholder)</div>
        <div className="p-4 bg-white rounded shadow">Books Management (placeholder)</div>
        <div className="p-4 bg-white rounded shadow">Billing & Plans (placeholder)</div>
      </section>
    </main>
  )
}
