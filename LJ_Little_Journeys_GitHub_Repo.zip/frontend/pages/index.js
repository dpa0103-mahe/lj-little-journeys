
import { useEffect, useState } from 'react'

export default function Home() {
  const [books, setBooks] = useState([])
  useEffect(() => {
    fetch('/api/books').then(r => r.json()).then(setBooks)
  }, [])
  return (
    <main className="min-h-screen p-8 bg-gray-50">
      <div className="flex items-center space-x-4 mb-4"><img src="/logo-placeholder.svg" alt="LJ logo" style={{width:80}} /><h1 className="text-3xl font-bold">Little Journeys — Book Reader</h1></div>
      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {books.map(b => (
          <article key={b.id} className="p-4 bg-white rounded shadow">
            <h2 className="text-xl font-semibold">{b.title}</h2>
            <p className="text-sm text-gray-600">{b.author}</p>
            <p className="mt-2">{b.excerpt}</p>
          </article>
        ))}
      </section>
    </main>
  )
}
