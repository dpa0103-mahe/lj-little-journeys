
import { useState } from 'react'

export default function Admin() {
  const [token, setToken] = useState('')
  const [form, setForm] = useState({ title: '', author: '', excerpt: '', content: '' })
  const [msg, setMsg] = useState('')

  async function login(e) {
    e.preventDefault()
    const res = await fetch('/api/auth/login', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ username: e.target.username.value, password: e.target.password.value }) })
    const data = await res.json()
    if (data.token) {
      setToken(data.token)
      setMsg('Logged in')
    } else {
      setMsg('Login failed: ' + (data.error || JSON.stringify(data)))
    }
  }

  async function addBook(e) {
    e.preventDefault()
    const res = await fetch('/api/books', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }, body: JSON.stringify(form) })
    const data = await res.json()
    if (data.id) setMsg('Book added: ' + data.title)
    else setMsg('Error: ' + (data.error || JSON.stringify(data)))
  }

  return (
    <main className="min-h-screen p-8 bg-gray-50">
      <h1 className="text-2xl font-bold mb-4">Admin — Little Journeys</h1>
      <section className="mb-6 p-4 bg-white rounded shadow">
        <h2 className="font-semibold">Login</h2>
        <form onSubmit={login} className="mt-2 space-y-2">
          <input name="username" placeholder="username" className="border p-2 w-full" />
          <input name="password" type="password" placeholder="password" className="border p-2 w-full" />
          <button className="px-4 py-2 bg-blue-600 text-white rounded">Login</button>
        </form>
      </section>

      <section className="p-4 bg-white rounded shadow">
        <h2 className="font-semibold">Add Book</h2>
        <form onSubmit={addBook} className="mt-2 space-y-2">
          <input value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="Title" className="border p-2 w-full" />
          <input value={form.author} onChange={e=>setForm({...form,author:e.target.value})} placeholder="Author" className="border p-2 w-full" />
          <input value={form.excerpt} onChange={e=>setForm({...form,excerpt:e.target.value})} placeholder="Excerpt" className="border p-2 w-full" />
          <textarea value={form.content} onChange={e=>setForm({...form,content:e.target.value})} placeholder="Content" className="border p-2 w-full" rows="6" />
          <button className="px-4 py-2 bg-green-600 text-white rounded">Add</button>
        </form>
        <p className="mt-2 text-sm text-gray-600">{msg}</p>
      </section>
    </main>
  )
}
