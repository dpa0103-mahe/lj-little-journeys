
import { useEffect, useRef, useState } from 'react'
import dynamic from 'next/dynamic'
import io from 'socket.io-client'
import localforage from 'localforage'
const ReactQuill = dynamic(() => import('react-quill'), { ssr: false })
import 'react-quill/dist/quill.snow.css'

let socket

export default function BookEditor({ query }) {
  const [book, setBook] = useState(null)
  const [content, setContent] = useState('')
  const [status, setStatus] = useState('offline')
  const [lockedSections, setLockedSections] = useState({})
  const quillRef = useRef(null)
  const bookId = query?.id || (typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('id') : null)

  useEffect(() => {
    if (!bookId) return
    // fetch book
    fetch(`/api/books/${bookId}`).then(r=>r.json()).then(data=>{ setBook(data); setContent(data.content || '') })
    // setup localforage store per book
    localforage.config({ name: 'lj', storeName: `book_${bookId}` })
    // restore offline edits if exist
    localforage.getItem('pending').then(p => {
      if (p) {
        // apply pending content
        setContent(p.content || '')
        setStatus(navigator.onLine ? 'syncing' : 'offline (has local edits)')
      }
    })
    // socket connect
    socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || (typeof window !== 'undefined' && window.location.origin) || 'http://localhost:4000')
    socket.on('connect', () => {
      socket.emit('join', { bookId, username: 'anon' })
      setStatus('online')
    })
    socket.on('doc', ({ content }) => {
      // receive full document state from server
      setContent(content || '')
    })
    socket.on('op', ({ delta }) => {
      // if delta.full present, replace content (simple approach)
      if (delta && delta.full !== undefined) setContent(delta.full)
    })
    socket.on('lock', ({ sectionId, by }) => {
      setLockedSections(s => ({ ...s, [sectionId]: by }))
    })
    socket.on('unlock', ({ sectionId }) => {
      setLockedSections(s => { const c = { ...s }; delete c[sectionId]; return c })
    })
    socket.on('saved', ()=> setStatus('saved'))

    window.addEventListener('online', syncPending)
    window.addEventListener('offline', ()=> setStatus('offline'))

    return () => {
      if (socket) socket.disconnect()
      window.removeEventListener('online', syncPending)
      window.removeEventListener('offline', ()=>{})
    }
  }, [bookId])

  // save to server (and broadcast via socket)
  async function save() {
    const payload = { title: book.title, author: book.author, excerpt: book.excerpt, content }
    const token = '' // admin token if available
    try {
      const r = await fetch(`/api/books/${bookId}`, { method: 'PUT', headers: {'Content-Type':'application/json', 'Authorization': token ? 'Bearer '+token : '' }, body: JSON.stringify(payload) })
      const data = await r.json()
      // notify others via socket
      if (socket) socket.emit('op', { bookId, delta: { full: content } })
      if (socket) socket.emit('save', { bookId })
      setStatus('saved')
    } catch (err) {
      // offline: save to IndexedDB
      await localforage.setItem('pending', { content, updatedAt: Date.now() })
      setStatus('offline (saved locally)')
    }
  }

  // sync pending local edits to server when back online
  async function syncPending() {
    const p = await localforage.getItem('pending')
    if (p) {
      try {
        await fetch(`/api/books/${bookId}`, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ title: book.title, author: book.author, excerpt: book.excerpt, content: p.content }) })
        await localforage.removeItem('pending')
        setStatus('synced')
        if (socket) socket.emit('op', { bookId, delta: { full: p.content } })
      } catch (err) {
        console.error('Sync failed', err)
      }
    }
  }

  // basic section locking (paragraph-level). sectionId is index
  function lockSection(idx) {
    if (!socket) return
    socket.emit('lock', { bookId, sectionId: String(idx), user: 'anon' })
  }
  function unlockSection(idx) {
    if (!socket) return
    socket.emit('unlock', { bookId, sectionId: String(idx), user: 'anon' })
  }

  return (
    <main className="min-h-screen p-8 bg-gray-50">
      <h1 className="text-2xl font-bold mb-4">{book ? book.title : 'Loading...'}</h1>
      <p className="mb-4 text-sm text-gray-600">Status: {status}</p>
      <div className="mb-4">
        <button onClick={save} className="px-4 py-2 bg-blue-600 text-white rounded mr-2">Save</button>
        <button onClick={syncPending} className="px-4 py-2 bg-green-600 text-white rounded">Sync Pending</button>
      </div>
      <div className="bg-white p-4 rounded shadow">
        <ReactQuill theme="snow" value={content} onChange={(val, delta, source, editor)=>{
          setContent(val)
          // broadcast small updates to others (character-by-character style)
          if (socket && source === 'user') {
            socket.emit('op', { bookId, delta: { full: val } })
          }
        }} ref={quillRef} />
      </div>
      <section className="mt-6 bg-white p-4 rounded shadow">
        <h2 className="font-semibold mb-2">Section locks (paragraphs)</h2>
        {(content || '').split('\n').slice(0,10).map((p, idx) => (
          <div key={idx} className="flex items-center justify-between border-b py-2">
            <div className="max-w-3xl text-sm">{p.slice(0,120) || <em>empty</em>}</div>
            <div className="text-sm">
              {lockedSections[String(idx)] ? <span>Locked by {lockedSections[String(idx)]}</span> : <button onClick={()=>lockSection(idx)} className="px-2 py-1 bg-yellow-400 rounded">Lock</button>}
              {lockedSections[String(idx)] === 'anon' ? <button onClick={()=>unlockSection(idx)} className="ml-2 px-2 py-1 bg-gray-200 rounded">Unlock</button> : null}
            </div>
          </div>
        ))}
      </section>
    </main>
  )
}

BookEditor.getInitialProps = ({ query }) => {
  return { query }
}
