
Frontend notes:
- Editor page: /book/[id] (for example /book/1)
- Uses react-quill for rich text editing, socket.io-client for realtime updates, and localforage for offline persistence.
- Environment: NEXT_PUBLIC_SOCKET_URL can be set to point socket.io server (defaults to same origin).
