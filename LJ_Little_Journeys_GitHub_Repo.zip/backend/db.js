// backend/db.js
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database(':memory:');

db.serialize(() => {
  db.run("CREATE TABLE books (id INTEGER PRIMARY KEY, title TEXT, author TEXT, excerpt TEXT, content TEXT)");
  const stmt = db.prepare("INSERT INTO books (title, author, excerpt, content) VALUES (?, ?, ?, ?)");
  stmt.run('The Little Cloud', 'A. Storyteller', 'A small cloud goes on a big journey...', 'Full content of The Little Cloud...');
  stmt.run('Moonlight Walks', 'B. Dreamer', 'Walking under the moon...', 'Full content of Moonlight Walks...');
  stmt.finalize();
});

module.exports = db;