
require('dotenv').config()
const express = require('express')
const cors = require('cors')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const { Pool } = require('pg')
const http = require('http')
const { Server } = require('socket.io')
const fetch = (...args) => import('node-fetch').then(({default: f}) => f(...args))

const app = express()
app.use(cors())
app.use(express.json())

const pool = new Pool({ connectionString: process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/little_journeys' })

// Initialize tables and seed data
async function initDB() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS books (
      id SERIAL PRIMARY KEY,
      title TEXT NOT NULL,
      author TEXT,
      excerpt TEXT,
      content TEXT
    );
  `)
  // seed admin user if not exists
  const adminUser = await pool.query("SELECT id FROM users WHERE username='admin'")
  if (adminUser.rowCount === 0) {
    const hash = await bcrypt.hash('password123', 10)
    await pool.query('INSERT INTO users (username, password_hash) VALUES ($1,$2)', ['admin', hash])
    console.log('Seeded admin user (admin / password123)')
  }
  // seed sample books if none exist
  const books = await pool.query('SELECT id FROM books LIMIT 1')
  if (books.rowCount === 0) {
    await pool.query("INSERT INTO books (title, author, excerpt, content) VALUES ($1,$2,$3,$4)", 
      ['The Little Cloud', 'A. Storyteller', 'A small cloud goes on a big journey...', 'Once upon a time...'])
    await pool.query("INSERT INTO books (title, author, excerpt, content) VALUES ($1,$2,$3,$4)", 
      ['Moonlight Walks', 'B. Dreamer', 'Walking under the moon...', 'It was a cool night...'])
    console.log('Seeded sample books')

// --- additional seed: pro test user & sample rich book ---
const proUser = await pool.query("SELECT id FROM users WHERE username='pro_user'");
if (proUser.rowCount === 0) {
  const hash2 = await bcrypt.hash('propass123', 10);
  await pool.query('INSERT INTO users (username, password_hash) VALUES ($1,$2)', ['pro_user', hash2]);
  console.log('Seeded pro user (pro_user / propass123)');
}
const richBook = await pool.query("SELECT id FROM books WHERE title='The Brave Little Explorer'");
if (richBook.rowCount === 0) {
  await pool.query("INSERT INTO books (title, author, excerpt, content) VALUES ($1,$2,$3,$4)",
    ['The Brave Little Explorer', 'LJ Stories', 'A short tale of a brave child explorer', "\n<h1>The Brave Little Explorer</h1>\n<p>Once upon a time, in a cosy little village, lived a curious child named Mira. She loved maps, stories and tiny adventures.</p>\n<p>One bright morning, Mira packed her small backpack with a sandwich, a magnifying glass and a tiny blue notebook. She waved goodbye and set off to find the secret hill where the clouds touched the trees.</p>\n<p>Along the way she met a friendly squirrel who showed her a path of shiny pebbles. Together they crossed a wooden bridge and reached a meadow full of flowers that hummed like bees.</p>\n<p>At the top of the hill, Mira unfolded her map and found a hidden note that said: <em>\u201cAdventure is for those who look.\u201d</em></p>\n<p>She sat down, opened her notebook and wrote a new story about the day she found the secret hill. Then she walked back home with a smile and a head full of new journeys to share.</p>\n<p><strong>The End</strong></p>\n"]);
  console.log('Seeded sample rich book');
}

  }
}

initDB().catch(err => console.error('DB init error', err))

// Auth helpers
const JWT_SECRET = process.env.JWT_SECRET || 'change-me'
function sign(user) {
  return jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '7d' })
}
function authMiddleware(req, res, next) {
  const h = req.headers.authorization
  if (!h) return res.status(401).json({ error: 'missing auth' })
  const token = h.split(' ')[1]
  try {
    const payload = jwt.verify(token, JWT_SECRET)
    req.user = payload
    next()
  } catch (err) {
    res.status(401).json({ error: 'invalid token' })
  }
}

// Routes
app.post('/auth/register', async (req, res) => {
  const { username, password } = req.body
  if (!username || !password) return res.status(400).json({ error: 'username & password required' })
  const hash = await bcrypt.hash(password, 10)
  try {
    const r = await pool.query('INSERT INTO users (username, password_hash) VALUES ($1, $2) RETURNING id, username', [username, hash])
    const user = r.rows[0]
    res.json({ user, token: sign(user) })
  } catch (err) {
    res.status(400).json({ error: 'user exists or invalid', details: err.message })
  }
})

app.post('/auth/login', async (req, res) => {
  const { username, password } = req.body
  if (!username || !password) return res.status(400).json({ error: 'username & password required' })
  const r = await pool.query('SELECT id, username, password_hash FROM users WHERE username=$1', [username])
  const user = r.rows[0]
  if (!user) return res.status(401).json({ error: 'invalid credentials' })
  const ok = await bcrypt.compare(password, user.password_hash)
  if (!ok) return res.status(401).json({ error: 'invalid credentials' })
  res.json({ user: { id: user.id, username: user.username }, token: sign(user) })
})

// Books REST API
app.get('/books', async (req, res) => {
  const r = await pool.query('SELECT id, title, author, excerpt FROM books ORDER BY id DESC')
  res.json(r.rows)
})

app.get('/books/:id', async (req, res) => {
  const r = await pool.query('SELECT * FROM books WHERE id=$1', [req.params.id])
  if (!r.rows[0]) return res.status(404).json({ error: 'Not found' })
  res.json(r.rows[0])
})

app.post('/books', authMiddleware, async (req, res) => {
  const { title, author, excerpt, content } = req.body
  if (!title) return res.status(400).json({ error: 'title required' })
  const r = await pool.query('INSERT INTO books (title, author, excerpt, content) VALUES ($1,$2,$3,$4) RETURNING id, title, author, excerpt', [title, author, excerpt, content])
  res.json(r.rows[0])
})

app.put('/books/:id', authMiddleware, async (req, res) => {
  const { title, author, excerpt, content } = req.body
  const r = await pool.query('UPDATE books SET title=$1, author=$2, excerpt=$3, content=$4 WHERE id=$5 RETURNING *', [title, author, excerpt, content, req.params.id])
  res.json(r.rows[0])
})

// Summarize (proxy to AI service)
app.post('/summarize', async (req, res) => {
  const { bookId } = req.body
  const r = await pool.query('SELECT content FROM books WHERE id=$1', [bookId])
  if (!r.rows[0]) return res.status(404).json({ error: 'book not found' })
  try {
    const aiResp = await fetch(process.env.AI_SERVICE_URL || 'http://localhost:8000/summarize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: r.rows[0].content })
    })
    const data = await aiResp.json()
    res.json(data)
  } catch (err) {
    res.status(500).json({ error: 'AI service unreachable', details: err.message })
  }
})

// HTTP + Socket.io for realtime collaboration
const server = http.createServer(app)
const io = new Server(server, { cors: { origin: '*' } })

// In-memory document cache to reduce DB writes (simple)
const docCache = new Map()

io.on('connection', (socket) => {
  console.log('socket connected', socket.id)

  socket.on('join', async ({ bookId, username }) => {
    const room = `book_${bookId}`
    socket.join(room)
    // load doc from cache or DB
    if (!docCache.has(bookId)) {
      const r = await pool.query('SELECT content FROM books WHERE id=$1', [bookId])
      const content = r.rows[0] ? r.rows[0].content : ''
      docCache.set(bookId, { content, locks: {} })
    }
    // send current state
    socket.emit('doc', { content: docCache.get(bookId).content })
    io.to(room).emit('presence', { user: username, id: socket.id })
  })

  // operational update: apply delta (we accept simple text patches)
  socket.on('op', ({ bookId, delta, cursor }) => {
    // naive approach: delta is the full content replacement or a small patch
    const state = docCache.get(bookId) || { content: '' }
    // if delta.full exists, replace; else apply naive append/replace
    if (delta.full !== undefined) state.content = delta.full
    else if (delta.patch !== undefined) state.content = delta.patch
    else if (typeof delta === 'string') state.content = delta
    docCache.set(bookId, state)
    // broadcast to others
    socket.to(`book_${bookId}`).emit('op', { delta, cursor, from: socket.id })
  })

  // section lock/unlock
  socket.on('lock', ({ bookId, sectionId, user }) => {
    const state = docCache.get(bookId) || { content: '', locks: {} }
    if (!state.locks) state.locks = {}
    // simple lock model: if not locked, set lock; otherwise ignore/conflict
    if (!state.locks[sectionId]) {
      state.locks[sectionId] = { by: user, at: Date.now() }
      io.to(`book_${bookId}`).emit('lock', { sectionId, by: user })
    } else {
      socket.emit('lock-error', { sectionId, message: 'Already locked' })
    }
    docCache.set(bookId, state)
  })

  socket.on('unlock', ({ bookId, sectionId, user }) => {
    const state = docCache.get(bookId) || { content: '', locks: {} }
    if (state.locks && state.locks[sectionId] && state.locks[sectionId].by === user) {
      delete state.locks[sectionId]
      io.to(`book_${bookId}`).emit('unlock', { sectionId })
    }
    docCache.set(bookId, state)
  })

  // save request: persist docCache to DB
  socket.on('save', async ({ bookId }) => {
    const state = docCache.get(bookId)
    if (!state) return
    try {
      await pool.query('UPDATE books SET content=$1 WHERE id=$2', [state.content, bookId])
      socket.emit('saved', { bookId, ok: true })
    } catch (err) {
      socket.emit('saved', { bookId, ok: false, error: err.message })
    }
  })

  socket.on('disconnect', () => {
    // handle disconnect presence if needed
  })
})

const port = process.env.PORT || 4000
server.listen(port, () => console.log('Backend running on', port))
