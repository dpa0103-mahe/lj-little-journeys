
Stripe setup (placeholder)
--------------------------
1. Create a Stripe account at https://dashboard.stripe.com/register
2. Get your API keys from Developers -> API keys
   - Set STRIPE_SECRET_KEY in Railway env variables
   - Set STRIPE_WEBHOOK_SECRET for webhook verification (optional but recommended)
3. The backend includes webhook endpoint: POST /webhooks/stripe
   - Configure the webhook in Stripe dashboard to send events to https://<your-railway-url>/webhooks/stripe
4. On successful checkout or subscription event, the webhook should update the user's 'is_paid' status.
5. For testing, use Stripe test keys and the Stripe CLI to send webhook events locally.
