
from fastapi import FastAPI
from pydantic import BaseModel
import os
import httpx
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title='LJ AI Service')

class SummarizeRequest(BaseModel):
    text: str

@app.post('/summarize')
async def summarize(req: SummarizeRequest):
    # Example: call OpenAI's API if OPENAI_API_KEY is provided; otherwise return a fake summary.
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
    if not OPENAI_API_KEY:
        # Return a dummy summary for local development
        return { 'summary': req.text[:140] + ('...' if len(req.text) > 140 else '') }
    # If key exists, make a real request to OpenAI API (example using httpx)
    headers = {'Authorization': f'Bearer {OPENAI_API_KEY}', 'Content-Type': 'application/json'}
    payload = {
        'model': 'gpt-4o-mini', 
        'messages': [{'role':'user', 'content': f'Summarize the following text in 3 short bullets:\n\n{req.text}'}],
        'max_tokens': 200,
        'temperature': 0.3
    }
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post('https://api.openai.com/v1/chat/completions', json=payload, headers=headers)
        r.raise_for_status()
        data = r.json()
        # Extract assistant reply safely
        try:
            reply = data['choices'][0]['message']['content']
        except Exception:
            reply = data
        return { 'summary': reply }

if __name__ == '__main__':
    import uvicorn
    uvicorn.run('main:app', host='0.0.0.0', port=int(os.getenv('PORT', 8000)), reload=True)
